
CONTENTS OF THIS FILE
---------------------
 * WARNING
 * Introduction
 * Installation

WARNING
-------

AS OF FEB 28, 2013 - SUPPORT FOR UBERCART IN THE SPRINGBOARD PLATFORM
HAS BEEN DEPRECIATED IN FAVOR OF COMMERCE. WHILE THE RE-ARCHITECTURE OF
SPRINGBOARD 4 ALLOWS FOR USE OF UBERCART OR COMMERCE, JACKSONRIVER CANNOT
AT THIS TIME SUPPORT BOTH.

IF YOU NEED TO USE UBERCART FOR YOUR SITE, THE CODE CONTAINED IN THIS
ZIP FILE WILL SERVE YOUR NEEDS UP TO FEATURES RELEASED BY 2/28/13. BE SURE
TO TEST YOUR SITE BEFORE GOING LIVE FOR ANY FEATURES AFTER THAT DATE.

INTRODUCTION
------------

Current Maintainer: Jackson River http://jacksonriver.com

This module provides an Ubercart based implementation for storing donations
as orders. It implements the fundraiser hooks required to handle donations
and respond to the donation life cycle.

INSTALLATION
------------

1. Unzip and copy this directory to your sites/SITENAME/modules directory. 

2. Enable the module. 

3. Configure user permissions at admin/user/permissions.