Drupal.behaviors.ogoneECommerce = {
  attach: function(context) { (function($) {

  $('#ogone-ecommerce-post').submit();

  })(jQuery); }
}