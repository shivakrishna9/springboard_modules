<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
<div class="g-plusone" data-size="<?php print $button_size?>" data-annotation="<?php print $annotation?>" data-href="<?php print $link_url ?> data-description="<?php print $description ?>"></div>
